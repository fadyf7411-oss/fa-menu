import { CategoryNav } from '@/components/category-nav'
import { MenuHero } from '@/components/menu-hero'
import { MenuSection } from '@/components/menu-section'
import { menu } from '@/lib/menu'

export default function Page() {
  return (
    <>
      <MenuHero />
      <CategoryNav categories={menu} />
      <main className="mx-auto flex max-w-3xl flex-col gap-14 px-5 py-10">
        {menu.map((category) => (
          <MenuSection key={category.id} category={category} />
        ))}
      </main>
      <footer className="bg-foreground px-5 py-8 text-center text-sm text-background/80">
        <p className="font-display text-2xl text-background">كريب وفينو</p>
        <p className="mt-2">الأسعار شاملة الضريبة · التوصيل متاح لحد باب البيت</p>
      </footer>
    </>
  )
}
