export type MenuItem = {
  name: string
  description?: string
  price: number
  tag?: string
}

export type MenuCategory = {
  id: string
  title: string
  subtitle: string
  items: MenuItem[]
}

export const menu: MenuCategory[] = [
  {
    id: 'sandwiches',
    title: 'سندوتشات',
    subtitle: 'عيش فينو أو سوري طازة',
    items: [
      { name: 'شاورما فراخ', description: 'شاورما فراخ، ثومية، خيار مخلل', price: 75, tag: 'الأكثر طلبًا' },
      { name: 'شاورما لحمة', description: 'شاورما لحمة، طحينة، بصل وطماطم', price: 95 },
      { name: 'كرسبي', description: 'صدور فراخ مقرمشة، خس، صوص رانش', price: 85 },
      { name: 'زنجر', description: 'فراخ سبايسي مقرمشة، مايونيز حار', price: 90 },
      { name: 'كبدة إسكندراني', description: 'كبدة متبلة بالفلفل الحار والليمون', price: 50 },
      { name: 'سجق', description: 'سجق بلدي، فلفل ألوان، طحينة', price: 55 },
      { name: 'برجر كلاسيك', description: 'لحم بقري ١٥٠ جم، شيدر، صوص خاص', price: 110 },
    ],
  },
  {
    id: 'savory-crepes',
    title: 'كريب حادق',
    subtitle: 'عجينة رقيقة ومقرمشة',
    items: [
      { name: 'كريب فراخ بانيه', description: 'بانيه، موتزاريلا، صوص باربكيو', price: 105, tag: 'مميز' },
      { name: 'كريب شاورما', description: 'شاورما فراخ، بطاطس، ثومية', price: 100 },
      { name: 'كريب هوت دوج', description: 'هوت دوج، شيدر، كاتشب ومستردة', price: 85 },
      { name: 'كريب تونة', description: 'تونة، ذرة، زيتون، موتزاريلا', price: 90 },
      { name: 'كريب ميكس جبن', description: 'موتزاريلا، شيدر، رومي، كيري', price: 80 },
      { name: 'كريب سوبر ميكس', description: 'فراخ، لحمة، سجق، ميكس جبن', price: 140 },
    ],
  },
  {
    id: 'sweet-crepes',
    title: 'كريب حلو',
    subtitle: 'لعشاق الحلويات',
    items: [
      { name: 'نوتيلا موز', description: 'نوتيلا وشرائح موز طازة', price: 85, tag: 'الأكثر طلبًا' },
      { name: 'لوتس', description: 'صوص لوتس وبسكويت مطحون', price: 90 },
      { name: 'ميكس شوكولاتة', description: 'شوكولاتة بيضاء وسوداء وبندق', price: 95 },
      { name: 'مكسرات وعسل', description: 'عسل نحل ومكسرات مشكلة', price: 100 },
    ],
  },
  {
    id: 'sides',
    title: 'إضافات',
    subtitle: 'كمّل وجبتك',
    items: [
      { name: 'بطاطس صغيرة', price: 30 },
      { name: 'بطاطس كبيرة', price: 45 },
      { name: 'بطاطس بالجبنة', price: 55 },
      { name: 'أصابع موتزاريلا', description: '٦ قطع', price: 65 },
      { name: 'صوص إضافي', description: 'ثومية، رانش، باربكيو، حار', price: 10 },
    ],
  },
  {
    id: 'drinks',
    title: 'مشروبات',
    subtitle: 'ساقعة ومنعشة',
    items: [
      { name: 'كانز', description: 'بيبسي، سفن أب، ميراندا', price: 25 },
      { name: 'عصير برتقال فريش', price: 40 },
      { name: 'ليمون نعناع', price: 35 },
      { name: 'مياه معدنية', price: 10 },
    ],
  },
]
